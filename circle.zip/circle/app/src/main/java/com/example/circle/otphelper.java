package com.example.circle;

public class otphelper {
  public static int otpvalue;

  public static int getOtpvalue() {
    return otpvalue;
  }

  public static void setOtpvalue(int otpvalue) {
    otphelper.otpvalue = otpvalue;
  }
}
