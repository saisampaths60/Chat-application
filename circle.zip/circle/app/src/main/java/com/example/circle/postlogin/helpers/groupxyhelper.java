package com.example.circle.postlogin.helpers;

public class groupxyhelper {
  public static String groupx;
  public static String groupy;

  public static String getGroupy() {
    return groupy;
  }

  public static void setGroupy(String groupy) {
    groupxyhelper.groupy = groupy;
  }

  public static String getGroupx() {
    return groupx;
  }

  public static void setGroupx(String groupx) {
    groupxyhelper.groupx = groupx;
  }
}
