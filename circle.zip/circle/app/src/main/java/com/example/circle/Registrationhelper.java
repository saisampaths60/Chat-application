package com.example.circle;

public class Registrationhelper {
  public static String Name;
  public static String Role;
  public static String Branch;
  public static String Roll_number;
  public static String Passout_year;
  public static String Phone;
  public static String Email;
  public static String Domain_mail;
  public static String Password;
  public static String Displayname;

  public static String getDisplayname() {
    return Displayname;
  }

  public static void setDisplayname(String displayname) {
    Displayname = displayname;
  }

  public static String getName() {
    return Name;
  }

  public static void setName(String name) {
    Name = name;
  }

  public static String getRole() {
    return Role;
  }

  public static void setRole(String role) {
    Role = role;
  }

  public static String getBranch() {
    return Branch;
  }

  public static void setBranch(String branch) {
    Branch = branch;
  }

  public static String getRoll_number() {
    return Roll_number;
  }

  public static void setRoll_number(String roll_number) {
    Roll_number = roll_number;
  }

  public static String getPassout_year() {
    return Passout_year;
  }

  public static void setPassout_year(String passout_year) {
    Passout_year = passout_year;
  }

  public static String getPhone() {
    return Phone;
  }

  public static void setPhone(String phone) {
    Phone = phone;
  }

  public static String getEmail() {
    return Email;
  }

  public static void setEmail(String email) {
    Email = email;
  }

  public static String getDomain_mail() {
    return Domain_mail;
  }

  public static void setDomain_mail(String domain_mail) {
    Domain_mail = domain_mail;
  }

  public static String getPassword() {
    return Password;
  }

  public static void setPassword(String password) {
    Password = password;
  }
}
