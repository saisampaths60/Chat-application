package com.example.circle.postlogin;

import android.content.Context;

public class accountdetailshelper {
    public static Context getContext() {
        return context;
    }

    public static void setContext(Context context) {
        accountdetailshelper.context = context;
    }

    public static Context context;

}
