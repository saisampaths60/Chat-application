package com.example.circle.postlogin.helpers;

public class messageidhelper {
    public static int messageid=0;

    public static int getMessageid() {
        return messageid;
    }

    public static void setMessageid(int messageid) {
        messageidhelper.messageid = messageid;
    }
}
